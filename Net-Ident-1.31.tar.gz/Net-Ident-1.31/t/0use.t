use 5.010;
use strict;
use warnings;
use Test::More tests => 1;

use_ok('Net::Ident', ':fh', ':apache');
